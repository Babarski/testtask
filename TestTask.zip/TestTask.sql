-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: May 18, 2018 at 02:24 PM
-- Server version: 5.7.16
-- PHP Version: 5.5.38

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `TestTask`
--

-- --------------------------------------------------------

--
-- Table structure for table `dinnertable`
--

CREATE TABLE `dinnertable` (
  `id` int(11) NOT NULL,
  `seats` int(11) NOT NULL,
  `form` varchar(20) NOT NULL,
  `coordinateLength` int(11) NOT NULL,
  `coordinateWidth` int(11) NOT NULL,
  `sizeLength` int(11) NOT NULL,
  `sizeWidth` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `dinnertable`
--

INSERT INTO `dinnertable` (`id`, `seats`, `form`, `coordinateLength`, `coordinateWidth`, `sizeLength`, `sizeWidth`) VALUES
(1, 4, 'square', 20, 25, 5, 5),
(4, 3, 'round', 50, 20, 5, 5),
(5, 2, 'square', 75, 20, 5, 5),
(6, 2, 'square', 23, 78, 5, 5),
(7, 5, 'round', 65, 65, 7, 7);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `idDinnerTable` int(11) NOT NULL,
  `date` date NOT NULL,
  `ordersName` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `idDinnerTable`, `date`, `ordersName`) VALUES
(1, 1, '2018-05-16', 'dima'),
(4, 4, '2018-05-16', 'dima'),
(5, 1, '2018-05-17', 'dima'),
(6, 1, '2018-05-18', 'Babarski'),
(7, 4, '2018-05-18', 'Babarski'),
(8, 1, '2018-05-19', 'Babarski'),
(9, 6, '2018-05-19', 'Babarski'),
(11, 4, '2018-05-20', 'Babarski');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `login` varchar(40) NOT NULL,
  `password` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `login`, `password`) VALUES
(1, 'admin', 'admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `dinnertable`
--
ALTER TABLE `dinnertable`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `dinnertable`
--
ALTER TABLE `dinnertable`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
